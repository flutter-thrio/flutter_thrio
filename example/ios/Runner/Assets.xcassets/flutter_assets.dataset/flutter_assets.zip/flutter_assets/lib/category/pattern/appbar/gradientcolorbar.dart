import 'package:flutter/material.dart';

class GradientColorBar extends StatefulWidget {
  @override
  _GradientColorBarState createState() => _GradientColorBarState();
}

class _GradientColorBarState extends State<GradientColorBar> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
